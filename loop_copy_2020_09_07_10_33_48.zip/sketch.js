function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  strokeWeight(4);
  stroke(255);

  // hvis jeg kun vil have variablen i en funktion og glemt i resten kan jeg tilføje den til en function
  //var x=0;
  // Hvis jeg vil have et loop kan jeg bruge while. hvis den skal stoppe når x> width. Derfor skal jeg skrive at jeg vil have den fortsætter indtil x< width. 
 
  
  //Du kan skrive koden mere sammensat med for loop. Der kan godt være et loop inde i et loop hvis noget skal tegnes hver gang noget andet tegnes. 
  for(var x=0;x<= width;x=x+50){
    for(var s = 0;s <= height ;s+=50){
    fill(50)
  ellipse(x,s,25,25);
    }
  }
  
  
  
  
  //ellipse(x,200,25,25);
  //x=x+50;
  
  //ellipse(x,200,25,25);
  //x=x+50;
  
  //ellipse(x,200,25,25);
  //x=x+50;
  
  //ellipse(x,200,25,25);
  //x=x+50;
  
  //ellipse(x,200,25,25);
  //x=x+50;
}